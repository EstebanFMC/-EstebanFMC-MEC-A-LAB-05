
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Panel;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;



public class Interfaz extends javax.swing.JFrame {

    public Interfaz() {
       
        //opcion = OpcionesBox.getSelectedItem().toString();
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        OpcionesBox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        BarrasButtom = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        PastelButtom = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        OpcionesBox.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        OpcionesBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default", "Contagios por sexo", "Contagios por Ciudades", "Contagios por edad", "Medio de Contagio" }));
        OpcionesBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpcionesBoxActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("Filtros");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel1)
                    .addComponent(OpcionesBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(OpcionesBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        BarrasButtom.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BarrasButtom.setText("Graficar");
        BarrasButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BarrasButtomActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Gráfico de pastel");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Gráfico de barras");

        PastelButtom.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        PastelButtom.setText("Graficar");
        PastelButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PastelButtomActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(BarrasButtom)
                    .addComponent(jLabel4))
                .addGap(77, 77, 77)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(PastelButtom)
                    .addComponent(jLabel2))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BarrasButtom, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PastelButtom, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel3.setText("Contagios del Covid - 19. Enero 2022 - 2023");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(29, 29, 29))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


//METODOS CREADOS:

    int masculino = 0, femenino = 0; //NUMERO DE CONTAGIOS SEGUN EL SEXO
    public void ContagioPorSexo() throws FileNotFoundException, IOException{
        FileInputStream ArchivoEntrada = new FileInputStream("C:\\Users\\Esteb\\OneDrive\\Escritorio\\NumeroContagios.xlsx");
        XSSFWorkbook libro = new XSSFWorkbook (ArchivoEntrada);
        XSSFSheet hoja = libro.getSheetAt(0);
        for(Row fila : hoja)
        {
           Cell celda = fila.getCell(3);
           if(fila.getRowNum()!=0){
            if("M".equals(celda.getStringCellValue()))
            masculino++;
            else
            femenino++;
           } 
        }
        //System.out.println("Hubieron " + masculino + " contagios en el sexo masculino y " + femenino + " contagios en el sexo femenino");
    }
    
     
    int comunitaria = 0, relacionada = 0; //NUMERO DE CONTAGIOS SEGUN EL TIPO
    public void TipoContagio() throws FileNotFoundException, IOException{
       FileInputStream ArchivoEntrada = new FileInputStream("C:\\Users\\Esteb\\OneDrive\\Escritorio\\NumeroContagios.xlsx");
        XSSFWorkbook libro = new XSSFWorkbook (ArchivoEntrada);
        XSSFSheet hoja = libro.getSheetAt(0);
        
        for(Row fila : hoja){
            Cell celda = fila.getCell(4);
            if(fila.getRowNum()!= 0){
                if("Comunitaria".equals(celda.getStringCellValue()))
                    comunitaria++;
                else
                    relacionada ++;
            }
        }
        //System.out.println("Hubieron " + comunitaria + " contagios por tipo comunitario y " + relacionada + " contagios por tipo relacionada");
        
    }
    
    
    ArrayList<Double> Edades = new ArrayList<>();//LISTA CON TODAS LAS EDADES 
    ArrayList<Edad> ListaEdades = new ArrayList<>(); //LISTA CON TODAS LAS EDADES Y SU NUMERO DE CONTAGIOS
    public void Edades () throws FileNotFoundException, IOException{
        Edades.removeAll(Edades);
        ListaEdades.removeAll(ListaEdades);
        FileInputStream ArchivoEntrada = new FileInputStream("C:\\Users\\Esteb\\OneDrive\\Escritorio\\NumeroContagios.xlsx");
        XSSFWorkbook libro = new XSSFWorkbook (ArchivoEntrada);
        XSSFSheet hoja = libro.getSheetAt(0);
        
        
        //CAPTURA DE DATOS
        
        for (Row fila : hoja){
            Cell celda = fila.getCell(2);
            if(fila.getRowNum()!=0 && !Edades.contains(celda.getNumericCellValue()))//INGRESA LAS EDADES SI NO ESTAN YA EN EL ARRAY
                Edades.add(celda.getNumericCellValue());
        }        
        //System.out.println(Edades);
        
        
        //ALGORITMO DE SELECCIÓN Y ADICION DE LAS REPETICIONES Y EDAD EN LA LISTA "LISTAEDADES"

        for (int i = 0; i < Edades.size(); i ++) {
            int contador = 0;
            for(Row fila : hoja){
                Cell celda = fila.getCell(2);
                if(fila.getRowNum()!= 0 && celda.getNumericCellValue() == (Edades.get(i))){
                        contador++;
                    }
            }
            Edad objetoEdad = new Edad (Edades.get(i), contador);
            ListaEdades.add(objetoEdad);
        }
        //System.out.println("Lista de Edades: " + ListaEdades);
        
             
        //ALGORITMO DE ORDENAMIENTO DE MAYOR A MENOR SEGÚN LAS REPETICIONES DE CADA EDAD
        for (int i = 0; i < ListaEdades.size(); i++) {
            for (int j = 0; j < ListaEdades.size()-1; j++) {
                if((ListaEdades.get(i)).getRepeticiones() > (ListaEdades.get(j)).getRepeticiones()){
                    Edad auxiliar = ListaEdades.get(j);
                    ListaEdades.set(j, ListaEdades.get(i));
                    ListaEdades.set(i, auxiliar);
                }
            }
        }
        //System.out.println("ARRAY ORDENADO: " + ListaEdades);

    }
    
    
    
    
    ArrayList <String> Ciudades = new ArrayList<>();//LISTA PARA LAS CIUDADES EXISTENTES
    ArrayList <Ciudad> contagios = new ArrayList<>(); //ALMACENA LAS 3 CIUDADES CON MÁS CONTAGIOS
    ArrayList <Ciudad> ciudad_contagios = new ArrayList<>(); //LISTA ORDENADA DE MAYOR A  MENOR CON TODAS LAS CIUDADES Y SUS CONTAGIOS
    
    public void LeerYOrganizarCiudades() throws FileNotFoundException, IOException, InvalidFormatException{
        Ciudades.removeAll(Ciudades);
        contagios.removeAll(contagios);
        ciudad_contagios.removeAll(ciudad_contagios);
        
        FileInputStream ArchivoEntrada = new FileInputStream("C:\\Users\\Esteb\\OneDrive\\Escritorio\\NumeroContagios.xlsx");
        XSSFWorkbook libro = new XSSFWorkbook (ArchivoEntrada);
        XSSFSheet hoja = libro.getSheetAt(0);
        
            for(Row fila : hoja){ //LLENADO DE TODAS LAS CIUDADES DEL ARCHIVO
                Cell celda = fila.getCell(1);

                String contenido = celda.getStringCellValue();
                if(!Ciudades.contains(contenido) && !"Nombre municipio".equals(contenido)){
                    Ciudades.add(contenido);
                }
            }            
            
            for (int i = 0; i < Ciudades.size(); i++) { //LLENADO DE UNA LISTA CON CIUDAD Y CONTAGIOS. FUNCIONANDO CORRECTAMENTE 
            int contador = 0;
             for(Row fila : hoja){
                 Cell celda = fila.getCell(1);
                 String contenido = celda.getStringCellValue();
                 if(contenido.equals(Ciudades.get(i))){ 
                     contador++;
                 }
             }
             
             Ciudad ciudadContagios = new Ciudad(Ciudades.get(i), contador); 
             ciudad_contagios.add(ciudadContagios);
                
            }
           
           for (int i = 0; i < Ciudades.size(); i++) { //ALGORITMO DE ORDENAMIENTO MAYOR A MENOR. FUNCIONA CORRECTAMENTE
                for (int j = 0; j < Ciudades.size(); j++) { 
                     if((ciudad_contagios.get(i)).getContagios() > (ciudad_contagios.get(j)).getContagios())
                     {
                         Ciudad auxiliar = ciudad_contagios.get(j);
                         ciudad_contagios.set(j, ciudad_contagios.get(i));
                         ciudad_contagios.set(i, auxiliar);  
                     }
                }
           }
            //System.out.println("Las ciudades son: " + Ciudades);
           
            for (int i = 0; i < 3; i++) { //ASIGNACION DE LAS 3 CIUDADES CON MAYORES CONTAGIOS
            contagios.add(ciudad_contagios.get(i));
            }
          //  System.out.println(contagios); 
    }
    
    
    
    private void OpcionesBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpcionesBoxActionPerformed
       
       /*
        if("Medio de Contagio".equals(opcion)){   
        }
        else if(opcion.equals("Contagios por Ciudades")){
            
        }
        else if(opcion.equals("Contagios por edad")) {
                    
                }
        else if(opcion.equals(" Contagios por sexo")){
                            
                        }
        */
        
    }//GEN-LAST:event_OpcionesBoxActionPerformed
    
    private void PastelButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PastelButtomActionPerformed
          DefaultPieDataset datos = new DefaultPieDataset();
          String opcion = OpcionesBox.getSelectedItem().toString();
            
             if(opcion.equals("Contagios por sexo")){
                    try {
                        ContagioPorSexo();
                    }
                    catch (IOException ex) {
                        Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                    }
                datos.setValue("Masculino", masculino);
                datos.setValue("Femenino", femenino); 
                JFreeChart grafico_circular = ChartFactory.createPieChart("Contagios por sexo", datos, true, true, false);
                grafico_circular.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de pastel", grafico_circular);
                frame.setLocationRelativeTo(null);
                frame.pack();
                frame.setVisible(true);
             }
             else if(opcion.equals("Contagios por edad")){
                try {
                    Edades();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                for(int i = 0; i < 3; i++){
                    datos.setValue(((ListaEdades.get(i)).getEdad()).toString(),((ListaEdades.get(i)).getRepeticiones()));
                }
               
                JFreeChart grafico_circular = ChartFactory.createPieChart("Top 3 Contagios por edad", datos, true, true, false);
                grafico_circular.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de pastel", grafico_circular);
                
                frame.pack();
                frame.setVisible(true);
                
                
             }
             else if(opcion.equals("Medio de Contagio")){
               try {
                    TipoContagio();
                 } catch (IOException ex) {
                  Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                 }
                datos.setValue("Cominitaria", comunitaria);
                datos.setValue("Relacionada", relacionada); 
                JFreeChart grafico_circular = ChartFactory.createPieChart("Medio de contagio", datos, true, true, false);
                grafico_circular.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de pastel", grafico_circular);
               
                frame.pack();
                frame.setVisible(true);
             }
             else if(opcion.equals("Contagios por Ciudades")){
                 try {
                     LeerYOrganizarCiudades();
                 } catch (IOException | InvalidFormatException ex) {
                  Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                 }
                 
                for(Ciudad x : contagios){
                datos.setValue(x.getNombre(),x.getContagios() );
                
                }
                JFreeChart grafico_circular = ChartFactory.createPieChart("Top 3 de las ciudades con más contagios", datos, true, true, false);
                grafico_circular.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de pastel", grafico_circular);
                
                frame.pack();
                frame.setVisible(true);
             }
    }//GEN-LAST:event_PastelButtomActionPerformed

    private void BarrasButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BarrasButtomActionPerformed
       DefaultCategoryDataset datos = new DefaultCategoryDataset();
       String opcion = OpcionesBox.getSelectedItem().toString();
       
       if(opcion.equals("Contagios por sexo")){
                    try {
                        ContagioPorSexo();
                    }
                    catch (IOException ex) {
                        Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    datos.setValue(masculino, "Masculino" , "");
                    datos.setValue(femenino, "Femenino" , "");
               
                JFreeChart grafico_barras = ChartFactory.createBarChart("Contagios por sexo", "Genero", "Contagios", datos, PlotOrientation.VERTICAL,true,false,false);
                grafico_barras.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de barras", grafico_barras);
                frame.pack();
                frame.setVisible(true);
             }
       
    
            else if(opcion.equals("Contagios por edad")){
                
                try {
                    Edades();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                for(int i = 0; i < 3; i++){
                    datos.setValue(((ListaEdades.get(i)).getRepeticiones()),((ListaEdades.get(i)).getEdad()).toString(), "");
                }
                
                JFreeChart grafico_barras = ChartFactory.createBarChart("Top 3 Contagios por edad", "Edad", "Contagios", datos, PlotOrientation.VERTICAL,true,false,false);
                grafico_barras.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de barras", grafico_barras);
                frame.pack();
                frame.setVisible(true);

                
             }
             else if(opcion.equals("Medio de Contagio")){
               try {
                    TipoContagio();
                 } catch (IOException ex) {
                  Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                 }
                datos.setValue(comunitaria, "Comunitaria", "");
                datos.setValue( relacionada, "Relacionada", "");
                
                JFreeChart grafico_barras = ChartFactory.createBarChart("Medio de Contagio", "Medio", "Contagios", datos, PlotOrientation.VERTICAL,true,false,false);
                grafico_barras.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de barras", grafico_barras);
                frame.pack();
                frame.setVisible(true);
}
             else if(opcion.equals("Contagios por Ciudades")){
                 try {
                     LeerYOrganizarCiudades();
                 } catch (IOException | InvalidFormatException ex) {
                  Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
                 }
                 
                for(Ciudad x : contagios){
                 datos.setValue(x.getContagios() ,x.getNombre(), "" );
                
                }
                
                JFreeChart grafico_barras = ChartFactory.createBarChart("Contagios por Ciudades", "Ciudad", "Contagios", datos, PlotOrientation.VERTICAL,true,false,false);
                grafico_barras.setBackgroundPaint(Color.white);
                ChartFrame frame = new ChartFrame("Gráfico de barras", grafico_barras);
                frame.pack();
                frame.setVisible(true);
             }
    }//GEN-LAST:event_BarrasButtomActionPerformed

 
    
    
  
    
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BarrasButtom;
    private javax.swing.JComboBox<String> OpcionesBox;
    private javax.swing.JButton PastelButtom;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
